package mk.edu.ugd.project;

public class CompanyRow{
    int image;
    String name;
    String address;
    String phoneNumber;
    String webPage;

    public CompanyRow(int image, String name, String address, String phoneNumber, String webPage) {
        this.image = image;
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.webPage = webPage;
    }

    public int getImage() {
        return image;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getWebPage() {
        return webPage;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setWebPage(String webPage) {
        this.webPage = webPage;
    }
}
