package mk.edu.ugd.project;

import android.content.Context;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class CompanyRowAdapter extends ArrayAdapter<CompanyRow> {
    private Context mContext;
    private int mResource;

    public CompanyRowAdapter(@NonNull Context context, int resource, @NonNull ArrayList<CompanyRow> objects) {
        super(context, resource, objects);
        this.mContext=context;
        this.mResource=resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(mContext);

        convertView =layoutInflater.inflate(mResource,parent,false);


        ImageView imageView = (ImageView)convertView.findViewById(R.id.imageView);
        TextView textName = (TextView)convertView.findViewById(R.id.textView2);
        TextView textAddress = (TextView)convertView.findViewById(R.id.textView3);
        TextView textPhoneNumber = (TextView)convertView.findViewById(R.id.textView1);
        TextView textWebPage = (TextView)convertView.findViewById(R.id.textView4);

        imageView.setImageResource(getItem(position).getImage());
        textName.setText(getItem(position).getName());
        textAddress.setText(getItem(position).getAddress());
        textPhoneNumber.setText(getItem(position).getPhoneNumber());
        textWebPage.setText(getItem(position).getWebPage());

        //textName.setMovementMethod(new ScrollingMovementMethod());
        //textName.setHorizontallyScrolling(true);



        return convertView;
        //return super.getView(position, convertView, parent);
    }
}
