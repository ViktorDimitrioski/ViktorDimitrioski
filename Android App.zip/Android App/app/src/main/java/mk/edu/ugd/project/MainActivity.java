package mk.edu.ugd.project;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.widget.ArrayAdapter;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    TabLayout tabLayout;
    ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabLayout = findViewById(R.id.tab_layout);
        viewPager = findViewById(R.id.view_pager);

        ArrayList<String> arrayList=new ArrayList<>();

        arrayList.add("Сервиси");
        arrayList.add("Забава");
        arrayList.add("Индустрија");
        arrayList.add("Едукација");




        prepareViewPager(viewPager, arrayList);

        tabLayout.setupWithViewPager(viewPager);

    }

    private void prepareViewPager(ViewPager viewPager, ArrayList<String> arrayList){

        //ArrayList<String> services=new ArrayList<>();
        //ArrayList<String> fun=new ArrayList<>();

        ArrayList<CompanyRow> companyRowServices = new ArrayList<>();
        ArrayList<CompanyRow> companyRowFun = new ArrayList<>();
        ArrayList<CompanyRow> companyRowIndustry = new ArrayList<>();
        ArrayList<CompanyRow> companyRowEducation = new ArrayList<>();


        companyRowServices.add(new CompanyRow(R.drawable.services_slika1,"Walmart","702 SW 8th Street","800-925-6278","walmart.com"));
        companyRowServices.add(new CompanyRow(R.drawable.services_slika2,"AWS","410 Terry Ave N","206-266-1000","aws.amazon.com"));
        companyRowServices.add(new CompanyRow(R.drawable.services_slika3,"Azure","Broad St, Seattle","0800-666-2842","azure.microsoft.com"));
        companyRowServices.add(new CompanyRow(R.drawable.services_slika4,"Google Drive","New York, NY 10011","1-866-246-6453","drive.google.com"));
        //companyRowServices.add(new CompanyRow(R.drawable.company,"CompanyForServices4444","Macedonia","072 252 852","www.company.com"));

        companyRowFun.add(new CompanyRow(R.drawable.slika_fun1,"Skywalker Trampolines","1006 Promontory Rd","866-603-5867","skywalkertrampolines.com"));
        companyRowFun.add(new CompanyRow(R.drawable.slika_fun2,"Rainbow Play","Glenwood Ave. Raleigh","919-420-0005","rainbowplay.com"));
        companyRowFun.add(new CompanyRow(R.drawable.slika_fun3,"Roller Derby","249 Litchfield, IL","217-324-3961","rollerderby.com"));
        companyRowFun.add(new CompanyRow(R.drawable.slika_fun4,"Alien Workshop","Boulder Ave, Dayton, OH","937-276-4243","alienworkshop.com"));
        //companyRowFun.add(new CompanyRow(R.drawable.fun,"CompanyForFun","Macedonia","072 252 852","www.company.com"));

        companyRowIndustry.add(new CompanyRow(R.drawable.slika_industry1,"Intel","2200 Mission College","408-765-8080","intel.com"));
        companyRowIndustry.add(new CompanyRow(R.drawable.slika_industry2,"Boeing","100, North Riverside","866-473-2016","boeing.com"));
        companyRowIndustry.add(new CompanyRow(R.drawable.slika_industry3,"Mercedes-Benz","Mercedesstraße 100, Stuttgard","49 711 1730000","mercedes-benz.com"));
        companyRowIndustry.add(new CompanyRow(R.drawable.slika_industry4,"Marathon Oil","5555 San Felipe St, Houston","800-822-4329","marathon-co.com"));
        //companyRowIndustry.add(new CompanyRow(R.drawable.fun,"CompanyForFun","Macedonia","072 252 852","www.company.com"));

        companyRowEducation.add(new CompanyRow(R.drawable.slika_education1,"Blackboard Inc.","120 Broadway New York","800-005-963","blackboard.com"));
        companyRowEducation.add(new CompanyRow(R.drawable.slika_education2,"Sharpie","6655 Peachtree Dunwoody Road","877-804-5383","sharpie.com"));
        companyRowEducation.add(new CompanyRow(R.drawable.slika_education3,"Paper Mate","2707 Butterfield Rd, Oak Brook","866-666-8735","papermate.com"));
        companyRowEducation.add(new CompanyRow(R.drawable.slika_education4,"Parker Pen","7137 E Stetson Drive Suite 7 Scottsdale","800-237-8736","parkerpen.com"));
        //companyRowEducation.add(new CompanyRow(R.drawable.fun,"CompanyForFun","Macedonia","072 252 852","www.company.com"));
        MainAdapter adapter = new MainAdapter(getSupportFragmentManager());

        MainFragment fragment = new MainFragment();

        for(int i=0;i<arrayList.size();i++) {
            Bundle bundle = new Bundle();
            if(i==0){
                for(int j=0;j<4;j++) {
                    bundle.putInt("slika"+j, companyRowServices.get(j).getImage());
                    bundle.putString("ime"+j,companyRowServices.get(j).getName());
                    bundle.putString("adresa"+j,companyRowServices.get(j).getAddress());
                    bundle.putString("telefonski_broj"+j,companyRowServices.get(j).getPhoneNumber());
                    bundle.putString("web_strana"+j,companyRowServices.get(j).getWebPage());
                }
            }else if(i==1){
                for(int j=0;j<4;j++) {
                    bundle.putInt("slika"+j, companyRowFun.get(j).getImage());
                    bundle.putString("ime"+j,companyRowFun.get(j).getName());
                    bundle.putString("adresa"+j,companyRowFun.get(j).getAddress());
                    bundle.putString("telefonski_broj"+j,companyRowFun.get(j).getPhoneNumber());
                    bundle.putString("web_strana"+j,companyRowFun.get(j).getWebPage());
                }
            }else if(i==2){
                for(int j=0;j<4;j++) {
                    bundle.putInt("slika"+j, companyRowIndustry.get(j).getImage());
                    bundle.putString("ime"+j,companyRowIndustry.get(j).getName());
                    bundle.putString("adresa"+j,companyRowIndustry.get(j).getAddress());
                    bundle.putString("telefonski_broj"+j,companyRowIndustry.get(j).getPhoneNumber());
                    bundle.putString("web_strana"+j,companyRowIndustry.get(j).getWebPage());
                }
            }else if(i==3)
                for(int j=0;j<4;j++) {
                    bundle.putInt("slika"+j, companyRowEducation.get(j).getImage());
                    bundle.putString("ime"+j,companyRowEducation.get(j).getName());
                    bundle.putString("adresa"+j,companyRowEducation.get(j).getAddress());
                    bundle.putString("telefonski_broj"+j,companyRowEducation.get(j).getPhoneNumber());
                    bundle.putString("web_strana"+j,companyRowEducation.get(j).getWebPage());
            }
            fragment.setArguments(bundle);

            adapter.addFragment(fragment,arrayList.get(i));

            fragment=new MainFragment();
        }
        viewPager.setAdapter(adapter);
    }

    private class MainAdapter extends FragmentPagerAdapter {
        ArrayList<String> arrayList=new ArrayList<>();
        List<Fragment> fragmentList = new ArrayList<>();

        public void addFragment(Fragment fragment, String title){
            arrayList.add(title);
            fragmentList.add(fragment);
        }

        public MainAdapter(@NonNull FragmentManager fm) {
            super(fm);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return fragmentList.get(position);
        }

        @Override
        public int getCount() {
            return fragmentList.size();
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return arrayList.get(position);
        }
    }
}