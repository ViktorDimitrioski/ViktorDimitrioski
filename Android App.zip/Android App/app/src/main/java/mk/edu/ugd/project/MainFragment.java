package mk.edu.ugd.project;

import android.media.Image;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MainFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MainFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public MainFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MainFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MainFragment newInstance(String param1, String param2) {
        MainFragment fragment = new MainFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_main, container, false);

        ListView listView = view.findViewById(R.id.list_view);


        /*int slika0 = getArguments().getInt("slika0");
        int slika1 = getArguments().getInt("slika1");
        int slika2 = getArguments().getInt("slika2");
        int slika3 = getArguments().getInt("slika3");
        int slika4 = getArguments().getInt("slika4");

        String ime0 = getArguments().getString("ime0");
        String ime1 = getArguments().getString("ime1");
        String ime2 = getArguments().getString("ime2");
        String ime3 = getArguments().getString("ime3");
        String ime4 = getArguments().getString("ime4");

        String adresa0 = getArguments().getString("adresa0");
        String adresa1 = getArguments().getString("adresa1");
        String adresa2 = getArguments().getString("adresa2");
        String adresa3 = getArguments().getString("adresa3");
        String adresa4 = getArguments().getString("adresa4");

        String telefonski_broj0 = getArguments().getString("telefonski_broj0");
        String telefonski_broj1 = getArguments().getString("telefonski_broj1");
        String telefonski_broj2 = getArguments().getString("telefonski_broj2");
        String telefonski_broj3 = getArguments().getString("telefonski_broj3");
        String telefonski_broj4 = getArguments().getString("telefonski_broj4");

        String web_strana0 = getArguments().getString("web_strana0");
        String web_strana1 = getArguments().getString("web_strana1");
        String web_strana2 = getArguments().getString("web_strana2");
        String web_strana3 = getArguments().getString("web_strana3");
        String web_strana4 = getArguments().getString("web_strana4");*/


        ArrayList<CompanyRow> companyRow = new ArrayList<>();

        for(int j=0;j<4;j++) {
            companyRow.add(new CompanyRow(getArguments().getInt("slika"+j), getArguments().getString("ime"+j),
                    getArguments().getString("adresa"+j), getArguments().getString("telefonski_broj"+j), getArguments().getString("web_strana"+j)));
        }

        //String[] days = {sTitle0,sTitle1,sTitle2,sTitle3,sTitle4,sTitle5,sTitle6,sTitle7,sTitle8};

        //ArrayAdapter<String> daysAdapter = new ArrayAdapter<>(getActivity(),R.layout.custom,R.id.textView1,days);

        CompanyRowAdapter companyRowAdapter = new CompanyRowAdapter(getActivity(),R.layout.custom,companyRow);

        listView.setAdapter(companyRowAdapter);

        //textView.setText(sTitle);

        return view;
    }
}